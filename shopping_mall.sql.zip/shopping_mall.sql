--
-- Database: `shopping mall`
--

-- --------------------------------------------------------

--
-- Table structure for table `accountant`
--

CREATE TABLE `accountant` (
  `ID` varchar(30) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Employee_ID` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accountant`
--

INSERT INTO `accountant` (`ID`, `Name`, `Employee_ID`) VALUES
('ACC01A01', 'Emily Dickens', 'A01EMP002');

-- --------------------------------------------------------

--
-- Table structure for table `advertisement_officer`
--

CREATE TABLE `advertisement_officer` (
  `ID` varchar(30) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Employee_ID` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `advertisement_officer`
--

INSERT INTO `advertisement_officer` (`ID`, `Name`, `Employee_ID`) VALUES
('MADV01', 'Patrick Nolan', 'MEMP005');

-- --------------------------------------------------------

--
-- Table structure for table `cleaning_crew`
--

CREATE TABLE `cleaning_crew` (
  `ID` varchar(30) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Employee_ID` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cleaning_crew`
--

INSERT INTO `cleaning_crew` (`ID`, `Name`, `Employee_ID`) VALUES
('MCCR01', 'David Murdox', 'MEMP004');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_No` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Contacts` varchar(20) NOT NULL,
  `Address` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Customer_No`, `Name`, `Contacts`, `Address`) VALUES
(20161026, 'Roy Mustang', '8974521789', '819 Amsterdam Eve');

-- --------------------------------------------------------

--
-- Table structure for table `customer_account`
--

CREATE TABLE `customer_account` (
  `Name` varchar(100) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `Mobile_No` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_account`
--

INSERT INTO `customer_account` (`Name`, `Username`, `Password`, `Mobile_No`) VALUES
('Elaric Salsman', 'elaric851', '@elaric851', '9517625410'),
('Himanshu Kumar', 'himanshu797', '@himanshu18', '7531059798'),
('Julian Forbes', 'julian_119', 'julian@119', '9865254187'),
('Koshal Kumar', 'koshal95', '@koshal95', '9465238715'),
('Nihar Ranjan', 'nihar111', '@nihar111', '9012365987'),
('Roy Mustang', 'roy_mustang_001', 'mustang@001', '8974521789');

-- --------------------------------------------------------

--
-- Table structure for table `employee_account`
--

CREATE TABLE `employee_account` (
  `Name` varchar(100) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `Mobile_No` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee_account`
--

INSERT INTO `employee_account` (`Name`, `Username`, `Password`, `Mobile_No`) VALUES
('Annie Jeans', 'annie_jeans_11', 'jeans@11', '8465174169'),
('Laura Bodwig', 'laura009', '@laura009', '8975412635'),
('Pankaj Meena', 'pankaj19', '@pankaj19', '9635410287');

-- --------------------------------------------------------

--
-- Table structure for table `event_organizer`
--

CREATE TABLE `event_organizer` (
  `ID` varchar(30) DEFAULT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Employee_ID` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event_organizer`
--

INSERT INTO `event_organizer` (`ID`, `Name`, `Employee_ID`) VALUES
('MEORG01', 'Amanda Kean', 'MEMP003');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `Inventory_No` varchar(20) NOT NULL,
  `Type` varchar(50) NOT NULL,
  `Max_Capacity` int(11) NOT NULL,
  `Current_Occupancy` int(11) NOT NULL,
  `Product_ID` varchar(30) NOT NULL,
  `Product_Name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`Inventory_No`, `Type`, `Max_Capacity`, `Current_Occupancy`, `Product_ID`, `Product_Name`) VALUES
('I_0001', 'Electronics', 50, 11, 'A_0001', 'Redmi Note 3');

-- --------------------------------------------------------

--
-- Table structure for table `mall_employee`
--

CREATE TABLE `mall_employee` (
  `Employee_ID` varchar(30) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `Age` varchar(11) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Contacts` varchar(20) NOT NULL,
  `Address` varchar(300) NOT NULL,
  `Year_Of_Joining` varchar(11) NOT NULL,
  `Year_Of_Leaving` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mall_employee`
--

INSERT INTO `mall_employee` (`Employee_ID`, `Name`, `Username`, `Age`, `Gender`, `Contacts`, `Address`, `Year_Of_Joining`, `Year_Of_Leaving`) VALUES
('MEMP001', 'Charles Davis', '', '32', 'Male', '9642398741', '29, 8th Avenue and 34th Street, New York', '2004', '0'),
('MEMP002', 'Annie Jeans', 'annie_jeans_11', '35', 'Female', '8465174169', '16, 7th Avenue and 34th Street, New York', '2008', '0'),
('MEMP003', 'Amanda Kean', '', '29', 'Female', '8974569712', '29 Brooklyn Street, NewYork', '2011', '0'),
('MEMP004', 'David Murdox', '', '44', 'Male', '7698415628', '891 Amsterdam Ave', '2007', '0'),
('MEMP005', 'Patrick Nolan', '', '36', 'Male', '7985462871', '742 Amsterdam Eve', '2009', '0'),
('MEMP006', 'Tom Denizen', '', '33', 'Male', '8974125648', '22 Brooklyn Street, NewYork', '2011', '0'),
('MEMP007', 'Aadarsh Sharma', 'aadarsh09', '28', 'Male', '8569741265', '266, G-7, Sector-17, Rohini', '2016-02-15', '');

-- --------------------------------------------------------

--
-- Table structure for table `mall_manager`
--

CREATE TABLE `mall_manager` (
  `Manager_ID` varchar(30) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Username` varchar(100) NOT NULL,
  `Employee_ID` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mall_manager`
--

INSERT INTO `mall_manager` (`Manager_ID`, `Name`, `Username`, `Employee_ID`) VALUES
('MMGR01', 'Annie Jeans', 'annie_jeans_11', 'MEMP002');

-- --------------------------------------------------------

--
-- Table structure for table `parked_vehicle`
--

CREATE TABLE `parked_vehicle` (
  `Vehicle_No` varchar(20) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Time_Of_Entry` time NOT NULL,
  `Time_Of_Exit` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parked_vehicle`
--

INSERT INTO `parked_vehicle` (`Vehicle_No`, `Name`, `Time_Of_Entry`, `Time_Of_Exit`) VALUES
('BR 268 456', 'Saanjh', '10:00:23', '12:26:10'),
('DH 126 569', 'Adarsh', '16:02:00', '17:23:23'),
('HR 001 256', 'Annie Jeans', '10:28:00', '18:05:00'),
('RJ 168 542', 'Roy Mustang', '15:24:00', '16:32:00');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `Product_ID` varchar(20) NOT NULL,
  `Product_Name` varchar(100) NOT NULL,
  `Type` varchar(50) NOT NULL,
  `Quantity` varchar(10) NOT NULL,
  `Shop_No` varchar(10) NOT NULL,
  `Manufacturer` varchar(100) NOT NULL,
  `Manufacturing_Date` date NOT NULL,
  `Expiry_Date` varchar(20) NOT NULL DEFAULT '""',
  `Price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`Product_ID`, `Product_Name`, `Type`, `Quantity`, `Shop_No`, `Manufacturer`, `Manufacturing_Date`, `Expiry_Date`, `Price`) VALUES
('E_001', 'Redmi Note 3', 'Electronics', '49', '7', 'Micromax', '2016-10-21', '', 10999),
('E_004', 'Dell Inspiron Core I3', 'Electronics', '8', '7', 'Micromax', '2016-10-21', '', 45999),
('E_005', 'Lenovo Z51-70 Core i7', 'Electronics', '8', '7', 'Micromax', '2016-10-21', '', 8999),
('E_006', 'Micromax 18.5 inch LED', 'Electronics', '4', '9', 'Micromax', '2016-10-21', '', 25000),
('G_001', 'Show Piece', 'Gifts', '8', '7', 'Micromax', '2016-10-21', '', 8999),
('G_002', 'Aluminium Peacock', 'Gifts', '8', '7', 'Micromax', '2016-10-21', '', 8999),
('K_001', 'Non Stick Tawa', 'Kitchen', '8', '7', 'Micromax', '2016-10-21', '', 8999),
('M_001', 'V.T. 54 Key Band Stand', 'Musicals', '8', '7', 'Micromax', '2016-10-21', '', 8999),
('M_002', 'Swan Harmonica', 'Musicals', '8', '7', 'Micromax', '2016-10-21', '', 8999),
('M_003', 'Tabla', 'Musicals', '8', '7', 'Micromax', '2016-10-21', '', 8999),
('P_001', 'Dog Collar', 'Pets', '49', '7', 'Micromax', '2016-10-21', '', 8999),
('P_002', 'Round Shape Bowl [Pets]', 'Pets', '8', '7', 'Micromax', '2016-10-21', '', 8999);

-- --------------------------------------------------------

--
-- Table structure for table `sales_person`
--

CREATE TABLE `sales_person` (
  `ID` varchar(30) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Employee_ID` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `security_chief`
--

CREATE TABLE `security_chief` (
  `ID` varchar(30) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Employee_ID` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `security_chief`
--

INSERT INTO `security_chief` (`ID`, `Name`, `Employee_ID`) VALUES
('MSECC01', 'Charles Davis', 'MEMP001');

-- --------------------------------------------------------

--
-- Table structure for table `security_guard`
--

CREATE TABLE `security_guard` (
  `ID` varchar(30) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Employee_ID` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `security_guard`
--

INSERT INTO `security_guard` (`ID`, `Name`, `Employee_ID`) VALUES
('MSECG01', 'Tom Denizen', 'MEMP006');

-- --------------------------------------------------------

--
-- Table structure for table `shop`
--

CREATE TABLE `shop` (
  `Shop_No` varchar(20) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Floor_No` varchar(20) NOT NULL,
  `Type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shop`
--

INSERT INTO `shop` (`Shop_No`, `Name`, `Floor_No`, `Type`) VALUES
('A_01', 'NIKE', '01', 'Clothing');

-- --------------------------------------------------------

--
-- Table structure for table `shop_cleaning_crew`
--

CREATE TABLE `shop_cleaning_crew` (
  `ID` varchar(30) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Employee_ID` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shop_cleaning_crew`
--

INSERT INTO `shop_cleaning_crew` (`ID`, `Name`, `Employee_ID`) VALUES
('CCR01A001', 'James Kurtton', 'A01EMP003');

-- --------------------------------------------------------

--
-- Table structure for table `shop_employee`
--

CREATE TABLE `shop_employee` (
  `Employee_ID` varchar(30) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Age` int(11) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Contacts` varchar(20) NOT NULL,
  `Address` varchar(300) NOT NULL,
  `Shop_No` varchar(20) NOT NULL,
  `Year_Of_Joining` varchar(30) NOT NULL,
  `Year_Of_Leaving` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shop_employee`
--

INSERT INTO `shop_employee` (`Employee_ID`, `Name`, `Age`, `Gender`, `Contacts`, `Address`, `Shop_No`, `Year_Of_Joining`, `Year_Of_Leaving`) VALUES
('A01EMP001', 'Charlie Armstrong', 30, 'Male', '8659742105', '21 Brooklyn Street, NewYork', 'A_01', '2009', ''),
('A01EMP002', 'Emily Dickens', 26, 'Female', '9741685264', '26 Brooklyn Street, NewYork', 'A_01', '2014', ''),
('A01EMP003', 'James Kurtton', 42, 'Male', '8467519875', '542 W. 27th Street, 4th Floor, New York, NY 10001', 'A_001', '2010', '');

-- --------------------------------------------------------

--
-- Table structure for table `shop_manager`
--

CREATE TABLE `shop_manager` (
  `Manager_ID` varchar(30) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Employee_ID` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shop_manager`
--

INSERT INTO `shop_manager` (`Manager_ID`, `Name`, `Employee_ID`) VALUES
('MGR01A01', 'Charlie Armstrong', 'A01EMP001');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accountant`
--
ALTER TABLE `accountant`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Employee_ID` (`Employee_ID`);

--
-- Indexes for table `advertisement_officer`
--
ALTER TABLE `advertisement_officer`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Employee_ID` (`Employee_ID`);

--
-- Indexes for table `cleaning_crew`
--
ALTER TABLE `cleaning_crew`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Employee_ID` (`Employee_ID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_No`);

--
-- Indexes for table `customer_account`
--
ALTER TABLE `customer_account`
  ADD PRIMARY KEY (`Username`);

--
-- Indexes for table `employee_account`
--
ALTER TABLE `employee_account`
  ADD PRIMARY KEY (`Username`);

--
-- Indexes for table `event_organizer`
--
ALTER TABLE `event_organizer`
  ADD KEY `Employee_ID` (`Employee_ID`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`Inventory_No`);

--
-- Indexes for table `mall_employee`
--
ALTER TABLE `mall_employee`
  ADD PRIMARY KEY (`Employee_ID`);

--
-- Indexes for table `mall_manager`
--
ALTER TABLE `mall_manager`
  ADD PRIMARY KEY (`Manager_ID`),
  ADD KEY `Employee_ID` (`Employee_ID`);

--
-- Indexes for table `parked_vehicle`
--
ALTER TABLE `parked_vehicle`
  ADD PRIMARY KEY (`Vehicle_No`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`Product_ID`),
  ADD KEY `Product_Index` (`Product_Name`);

--
-- Indexes for table `sales_person`
--
ALTER TABLE `sales_person`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Employee_ID` (`Employee_ID`);

--
-- Indexes for table `security_chief`
--
ALTER TABLE `security_chief`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Employee_ID` (`Employee_ID`);

--
-- Indexes for table `security_guard`
--
ALTER TABLE `security_guard`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Employee_ID` (`Employee_ID`);

--
-- Indexes for table `shop`
--
ALTER TABLE `shop`
  ADD PRIMARY KEY (`Shop_No`);

--
-- Indexes for table `shop_cleaning_crew`
--
ALTER TABLE `shop_cleaning_crew`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Employee_ID` (`Employee_ID`);

--
-- Indexes for table `shop_employee`
--
ALTER TABLE `shop_employee`
  ADD PRIMARY KEY (`Employee_ID`);

--
-- Indexes for table `shop_manager`
--
ALTER TABLE `shop_manager`
  ADD PRIMARY KEY (`Manager_ID`),
  ADD KEY `Employee_ID` (`Employee_ID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `accountant`
--
ALTER TABLE `accountant`
  ADD CONSTRAINT `accountant_ibfk_1` FOREIGN KEY (`Employee_ID`) REFERENCES `shop_employee` (`Employee_ID`);

--
-- Constraints for table `advertisement_officer`
--
ALTER TABLE `advertisement_officer`
  ADD CONSTRAINT `advertisement_officer_ibfk_1` FOREIGN KEY (`Employee_ID`) REFERENCES `mall_employee` (`Employee_ID`);

--
-- Constraints for table `cleaning_crew`
--
ALTER TABLE `cleaning_crew`
  ADD CONSTRAINT `cleaning_crew_ibfk_1` FOREIGN KEY (`Employee_ID`) REFERENCES `mall_employee` (`Employee_ID`);

--
-- Constraints for table `event_organizer`
--
ALTER TABLE `event_organizer`
  ADD CONSTRAINT `event_organizer_ibfk_1` FOREIGN KEY (`Employee_ID`) REFERENCES `mall_employee` (`Employee_ID`);

--
-- Constraints for table `mall_manager`
--
ALTER TABLE `mall_manager`
  ADD CONSTRAINT `mall_manager_ibfk_1` FOREIGN KEY (`Employee_ID`) REFERENCES `mall_employee` (`Employee_ID`);

--
-- Constraints for table `sales_person`
--
ALTER TABLE `sales_person`
  ADD CONSTRAINT `sales_person_ibfk_1` FOREIGN KEY (`Employee_ID`) REFERENCES `shop_employee` (`Employee_ID`);

--
-- Constraints for table `security_chief`
--
ALTER TABLE `security_chief`
  ADD CONSTRAINT `security_chief_ibfk_1` FOREIGN KEY (`Employee_ID`) REFERENCES `mall_employee` (`Employee_ID`);

--
-- Constraints for table `security_guard`
--
ALTER TABLE `security_guard`
  ADD CONSTRAINT `security_guard_ibfk_1` FOREIGN KEY (`Employee_ID`) REFERENCES `mall_employee` (`Employee_ID`);

--
-- Constraints for table `shop_cleaning_crew`
--
ALTER TABLE `shop_cleaning_crew`
  ADD CONSTRAINT `shop_cleaning_crew_ibfk_1` FOREIGN KEY (`Employee_ID`) REFERENCES `shop_employee` (`Employee_ID`);

--
-- Constraints for table `shop_manager`
--
ALTER TABLE `shop_manager`
  ADD CONSTRAINT `shop_manager_ibfk_1` FOREIGN KEY (`Employee_ID`) REFERENCES `shop_employee` (`Employee_ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
